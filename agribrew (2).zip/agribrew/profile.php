<?php
$page_title='Profile'; require_once __DIR__.'/includes/header.php';

$id=(int)$_SESSION['user']['id'];
$profile=$conn->query("SELECT * FROM users WHERE id=$id LIMIT 1")->fetch_assoc();
if(!$profile){flash('error','Profile not found.');redirect('dashboard.php');}

if(isset($_POST['save'])){
    $full=trim($_POST['full_name']);$email=trim($_POST['email']);$pos=trim($_POST['position']);$loc=trim($_POST['location']);
    $s=$conn->prepare("UPDATE users SET full_name=?,email=?,position=?,location=? WHERE id=?");$s->bind_param("ssssi",$full,$email,$pos,$loc,$id);$s->execute();
    $_SESSION['user']['full_name']=$full;$_SESSION['user']['email']=$email;$_SESSION['user']['position']=$pos;$_SESSION['user']['location']=$loc;
    flash('success','Profile updated.');redirect('profile.php');
}

if(isset($_POST['upload_photo'])){
    if(!isset($_FILES['profile_photo']) || $_FILES['profile_photo']['error'] !== UPLOAD_ERR_OK){
        flash('error','Please choose a valid image.');redirect('profile.php');
    }
    $file=$_FILES['profile_photo'];
    if($file['size'] > 5 * 1024 * 1024){flash('error','Profile photo must be 5 MB or smaller.');redirect('profile.php');}
    $finfo=new finfo(FILEINFO_MIME_TYPE);$mime=$finfo->file($file['tmp_name']);
    $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if(!isset($allowed[$mime])){flash('error','Only JPG, PNG, and WEBP images are allowed.');redirect('profile.php');}
    $filename='user_'.$id.'_'.bin2hex(random_bytes(6)).'.'.$allowed[$mime];
    $destination=$profile_upload_dir.$filename;
    if(!move_uploaded_file($file['tmp_name'],$destination)){flash('error','The photo could not be uploaded.');redirect('profile.php');}
    if(!empty($profile['profile_photo'])){
        $old=$profile_upload_dir.basename($profile['profile_photo']);
        if(is_file($old)){@unlink($old);}
    }
    $s=$conn->prepare("UPDATE users SET profile_photo=? WHERE id=?");$s->bind_param("si",$filename,$id);$s->execute();
    $_SESSION['user']['profile_photo']=$filename;
    flash('success','Profile photo updated.');redirect('profile.php');
}

if(isset($_POST['remove_photo'])){
    if(!empty($profile['profile_photo'])){
        $old=$profile_upload_dir.basename($profile['profile_photo']);
        if(is_file($old)){@unlink($old);}
    }
    $conn->query("UPDATE users SET profile_photo=NULL WHERE id=$id");
    $_SESSION['user']['profile_photo']=null;
    flash('success','Profile photo removed.');redirect('profile.php');
}

$photo=!empty($profile['profile_photo']) ? BASE_URL.'uploads/profiles/'.rawurlencode($profile['profile_photo']) : '';
?>
<div class="profile-layout">
    <div class="card profile-photo-card">
        <div class="profile-photo-wrap">
            <?php if($photo): ?><img class="profile-photo" src="<?=e($photo)?>" alt="Profile photo">
            <?php else: ?><div class="profile-photo profile-placeholder"><?=e(strtoupper(substr($profile['full_name'],0,1)))?></div><?php endif; ?>
        </div>
        <h3><?=e($profile['full_name'])?></h3>
        <p class="muted"><?=e($profile['role'])?></p>
        <form method="post" enctype="multipart/form-data" class="photo-form">
            <label class="btn secondary photo-upload-label">Upload Photo<input type="file" name="profile_photo" accept="image/jpeg,image/png,image/webp" required onchange="this.form.submit()"></label>
            <input type="hidden" name="upload_photo" value="1">
        </form>
        <?php if($photo): ?><form method="post" class="remove-photo-form"><button class="btn danger" name="remove_photo" onclick="return confirm('Remove your profile photo?')">Remove Photo</button></form><?php endif; ?>
        <small class="muted">JPG, PNG, or WEBP · Max 5 MB</small>
    </div>
    <div class="card profile-details-card">
        <div class="section-head"><div><span class="kicker">Account</span><h3>Your Profile</h3></div></div>
        <form method="post">
            <div class="form-grid">
                <div><label>Full Name</label><input name="full_name" required value="<?=e($profile['full_name'])?>"></div>
                <div><label>Email</label><input type="email" name="email" value="<?=e($profile['email']??'')?>"></div>
                <div><label>Position</label><input name="position" value="<?=e($profile['position']??'')?>"></div>
                <div><label>Location</label><input name="location" value="<?=e($profile['location']??'')?>"></div>
                <div><label>Username</label><input value="<?=e($profile['username'])?>" readonly></div>
                <div><label>Role</label><input value="<?=e($profile['role'])?>" readonly></div>
            </div>
            <div class="form-actions"><button class="btn primary" name="save">Update Profile</button></div>
        </form>
    </div>
</div>
<?php require_once __DIR__.'/includes/footer.php'; ?>
