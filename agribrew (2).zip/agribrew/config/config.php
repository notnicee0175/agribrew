<?php
session_start();

define('BASE_URL', 'http://localhost/agribrew/');
define('APP_NAME', 'AgriBrew');

$db_host = 'localhost';
$db_name = 'agribrew_db';
$db_user = 'root';
$db_pass = '';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

function ensure_column($table, $column, $definition) {
    global $conn;
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $column = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    $check = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    if ($check && $check->num_rows === 0) {
        $conn->query("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
    }
}

// Keep existing installations compatible with newer fields.
ensure_column('users', 'profile_photo', 'VARCHAR(255) DEFAULT NULL AFTER location');
ensure_column('farming_records', 'variety', 'VARCHAR(80) DEFAULT NULL AFTER farmer_name');
ensure_column('inventory', 'created_by', 'INT DEFAULT NULL AFTER reorder_level');
ensure_column('customers', 'created_by', 'INT DEFAULT NULL AFTER address');
ensure_column('price_list', 'created_by', 'INT DEFAULT NULL AFTER price');

// Keep the two supplied local demo accounts usable on existing installations.
// INSERT ... ON DUPLICATE KEY UPDATE also recreates a demo account if it was deleted.
$demo_accounts = [
    ['System Administrator', 'admin', '$2y$12$yKDwr2d.7kwpMtwGLIVY3efhIeR41u6wePTq/HZLPO7WyYs1Zk8tG', 'Administrator', 'admin@agribrew.local', 'Administrator'],
    ['Cooperative Staff', 'staff', '$2y$12$.h8ktEvvarh2t9beNUWsPeyz3bJTso5b.G7t/pyi9ZhoX5nUQ8PM.', 'Cooperative Staff', 'staff@agribrew.local', 'Cooperative Staff']
];
foreach ($demo_accounts as $demo) {
    $stmt = $conn->prepare("INSERT INTO users (full_name, username, password, role, email, position) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), password = VALUES(password), role = VALUES(role), email = VALUES(email), position = VALUES(position)");
    if ($stmt) {
        $stmt->bind_param('ssssss', $demo[0], $demo[1], $demo[2], $demo[3], $demo[4], $demo[5]);
        $stmt->execute();
        $stmt->close();
    }
}

$profile_upload_dir = __DIR__ . '/../uploads/profiles/';
if (!is_dir($profile_upload_dir)) {
    @mkdir($profile_upload_dir, 0755, true);
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header('Location: ' . BASE_URL . ltrim($path, '/'));
    exit;
}

function is_logged_in() {
    return isset($_SESSION['user']);
}

function require_login() {
    if (!is_logged_in()) {
        redirect('auth/login.php');
    }
}

function is_admin() {
    return isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'Administrator';
}

function can_manage_users() {
    return is_admin();
}

function can_edit_record($created_by) {
    return is_admin() || ((int)$created_by === (int)($_SESSION['user']['id'] ?? 0));
}

function can_delete_record($created_by) {
    return can_edit_record($created_by);
}

function flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function show_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        echo '<div class="alert ' . e($f['type']) . '">' . e($f['message']) . '</div>';
    }
}
?>
