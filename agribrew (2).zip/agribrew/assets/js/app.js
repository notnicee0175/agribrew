document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-search]').forEach(function (input) {
        const target = document.querySelector(input.dataset.search);
        if (!target) return;
        input.addEventListener('input', function () {
            const term = this.value.toLowerCase().trim();
            target.querySelectorAll('tbody tr').forEach(function (row) {
                row.style.display = row.innerText.toLowerCase().includes(term) ? '' : 'none';
            });
        });
    });

    document.querySelectorAll('[data-modal-open]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            document.querySelector(this.dataset.modalOpen).classList.add('show');
        });
    });

    document.querySelectorAll('[data-modal-close]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            document.querySelector(this.dataset.modalClose).classList.remove('show');
        });
    });

    document.querySelectorAll('.modal-backdrop').forEach(function (modal) {
        modal.addEventListener('click', function (event) {
            if (event.target === modal) modal.classList.remove('show');
        });
    });

    document.querySelectorAll('[data-enable-input]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const input = document.querySelector(this.dataset.enableInput);
            if (!input) return;
            input.readOnly = false;
            input.focus();
            if (input.showPicker) {
                try { input.showPicker(); } catch (e) {}
            }
            this.textContent = 'Editing';
            this.classList.add('active');
        });
    });

    document.querySelectorAll('[data-role-choice]').forEach(function (choice) {
        choice.addEventListener('click', function () {
            const role = this.dataset.roleChoice;
            const hidden = document.getElementById('selectedRole');
            if (hidden) hidden.value = role;
            document.querySelectorAll('[data-role-choice]').forEach(function (item) {
                item.classList.toggle('selected', item === choice);
            });
        });
    });

    const productInput = document.getElementById('saleProduct');
    const unitPriceInput = document.getElementById('saleUnitPrice');
    const priceHint = document.getElementById('priceHint');
    if (productInput && unitPriceInput && Array.isArray(window.agribrewPrices)) {
        function updateProductPrice() {
            const typed = productInput.value.trim().toLowerCase();
            const match = window.agribrewPrices.find(function (item) {
                return String(item.product_name).trim().toLowerCase() === typed;
            });
            if (match) {
                unitPriceInput.value = Number(match.price).toFixed(2);
                if (priceHint) priceHint.textContent = 'Unit price loaded from the Price List.';
            } else {
                unitPriceInput.value = '';
                if (priceHint) priceHint.textContent = typed ? 'No exact Price List match. Choose an added product.' : 'Select a Price List product to fill the unit price automatically.';
            }
        }
        productInput.addEventListener('input', updateProductPrice);
        updateProductPrice();
    }
});
