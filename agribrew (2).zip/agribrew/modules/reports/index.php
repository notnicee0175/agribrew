<?php
$page_title='Reports'; require_once __DIR__.'/../../includes/header.php';
$harvest=$conn->query("SELECT COALESCE(SUM(quantity),0) n FROM farming_records WHERE process_type='Harvesting'")->fetch_assoc()['n'];
$inventory=$conn->query("SELECT COALESCE(SUM(stock),0) n FROM inventory")->fetch_assoc()['n'];
$sales=$conn->query("SELECT COALESCE(SUM(total_price),0) n FROM sales")->fetch_assoc()['n'];
$expenses=$conn->query("SELECT COALESCE(SUM(amount),0) n FROM expenses")->fetch_assoc()['n'];
$report_date=date('F d, Y');
?>
<div class="grid cards-4">
    <div class="card stat-card"><div class="stat-label">Total Harvest</div><div class="stat-value"><?=number_format($harvest,2)?> kg</div></div>
    <div class="card stat-card"><div class="stat-label">Total Inventory</div><div class="stat-value"><?=number_format($inventory,2)?></div></div>
    <div class="card stat-card"><div class="stat-label">Total Sales</div><div class="stat-value">₱<?=number_format($sales,2)?></div></div>
    <div class="card stat-card"><div class="stat-label">Total Expenses</div><div class="stat-value">₱<?=number_format($expenses,2)?></div></div>
</div>

<div class="card report-library" style="margin-top:20px;">
    <div class="section-head"><div><span class="kicker">Report Center</span><h3>Generated Reports</h3></div></div>
    <div class="table-wrap"><table><thead><tr><th>Report ID</th><th>Report Type</th><th>Date Generated</th><th>Prepared By</th><th>Actions</th></tr></thead><tbody>
        <tr>
            <td>REP-2026-001</td>
            <td>Production Report</td>
            <td><?=e($report_date)?></td>
            <td><?=e($_SESSION['user']['full_name'])?></td>
            <td class="report-actions">
                <a class="btn secondary btn-small" href="view.php?type=production">View</a>
                <a class="btn primary btn-small" href="view.php?type=production&print=1" target="_blank">Report</a>
                <a class="btn secondary btn-small" href="download.php?type=production">Download PDF</a>
            </td>
        </tr>
    </tbody></table></div>
</div>

<?php require_once __DIR__.'/../../includes/footer.php'; ?>
