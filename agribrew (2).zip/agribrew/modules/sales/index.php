<?php
$page_title='Sales Transactions';
require_once __DIR__.'/../../includes/header.php';

if(isset($_POST['save'])){
    $invoice=trim($_POST['invoice_no']);
    $customer=(int)$_POST['customer_id'] ?: null;
    $product=trim($_POST['product_name']);
    $qty=(float)$_POST['quantity'];

    $price_stmt=$conn->prepare("SELECT price FROM price_list WHERE LOWER(product_name)=LOWER(?) ORDER BY id DESC LIMIT 1");
    $price_stmt->bind_param("s",$product);
    $price_stmt->execute();
    $price_row=$price_stmt->get_result()->fetch_assoc();
    if(!$price_row){flash('error','Please choose a product that exists in the Price List.');redirect('modules/sales/index.php');}
    $unit=(float)$price_row['price'];
    $total=$qty*$unit;
    $date=$_POST['transaction_date'];
    $status=$_POST['payment_status'];
    $uid=(int)$_SESSION['user']['id'];

    if(!empty($_POST['id'])){
        $id=(int)$_POST['id'];
        $check=$conn->prepare("SELECT created_by FROM sales WHERE id=?");
        $check->bind_param("i",$id); $check->execute(); $owner=$check->get_result()->fetch_assoc();
        if(!$owner || !can_edit_record($owner['created_by'])){flash('error','You can only edit transactions created by your account.');redirect('modules/sales/index.php');}
        $s=$conn->prepare("UPDATE sales SET invoice_no=?,customer_id=?,product_name=?,quantity=?,unit_price=?,total_price=?,transaction_date=?,payment_status=? WHERE id=?");
        $s->bind_param("sisdddssi",$invoice,$customer,$product,$qty,$unit,$total,$date,$status,$id);
    }else{
        $s=$conn->prepare("INSERT INTO sales(invoice_no,customer_id,product_name,quantity,unit_price,total_price,transaction_date,payment_status,created_by) VALUES(?,?,?,?,?,?,?,?,?)");
        $s->bind_param("sisdddssi",$invoice,$customer,$product,$qty,$unit,$total,$date,$status,$uid);
    }
    $s->execute(); flash('success','Sales transaction saved.'); redirect('modules/sales/index.php');
}

if(isset($_GET['delete'])){
    $id=(int)$_GET['delete'];
    $check=$conn->prepare("SELECT created_by FROM sales WHERE id=?"); $check->bind_param("i",$id); $check->execute(); $owner=$check->get_result()->fetch_assoc();
    if($owner && can_delete_record($owner['created_by'])){$s=$conn->prepare("DELETE FROM sales WHERE id=?");$s->bind_param("i",$id);$s->execute();flash('success','Transaction deleted.');}
    else{flash('error','You can only delete transactions created by your account.');}
    redirect('modules/sales/index.php');
}

$edit=null;
if(isset($_GET['edit'])){
    $id=(int)$_GET['edit'];$s=$conn->prepare("SELECT * FROM sales WHERE id=?");$s->bind_param("i",$id);$s->execute();$edit=$s->get_result()->fetch_assoc();
    if(!$edit || !can_edit_record($edit['created_by'])){flash('error','You can only edit transactions created by your account.');redirect('modules/sales/index.php');}
}
$customers=$conn->query("SELECT id,customer_name FROM customers ORDER BY customer_name");
$prices=$conn->query("SELECT product_name,unit,price FROM price_list ORDER BY product_name ASC");
$product_options=[]; while($p=$prices->fetch_assoc()){$product_options[]=$p;}
$rows=$conn->query("SELECT s.*,c.customer_name,u.full_name AS recorded_by FROM sales s LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN users u ON u.id=s.created_by ORDER BY s.transaction_date DESC,s.id DESC");
$revenue=$conn->query("SELECT COALESCE(SUM(total_price),0) n FROM sales")->fetch_assoc()['n'];
$count=$conn->query("SELECT COUNT(*) n FROM sales")->fetch_assoc()['n'];
$qty=$conn->query("SELECT COALESCE(SUM(quantity),0) n FROM sales")->fetch_assoc()['n'];
?>
<div class="grid cards-4"><div class="card stat-card"><div class="stat-label">Transactions</div><div class="stat-value"><?=$count?></div></div><div class="card stat-card"><div class="stat-label">Total Revenue</div><div class="stat-value">₱<?=number_format($revenue,2)?></div></div><div class="card stat-card"><div class="stat-label">Quantity Sold</div><div class="stat-value"><?=number_format($qty,2)?></div></div><div class="card stat-card"><div class="stat-label">Today</div><div class="stat-value">₱<?=number_format($conn->query("SELECT COALESCE(SUM(total_price),0) n FROM sales WHERE transaction_date=CURDATE()")->fetch_assoc()['n'],2)?></div></div></div>
<div class="card" style="margin-top:20px;"><div class="section-head"><h3>Sales Transactions</h3><button class="btn primary" data-modal-open="#salesModal">+ Record Sale</button></div><div class="toolbar"><input class="search" placeholder="Search transactions..." data-search="#salesTable"></div><div class="table-wrap"><table id="salesTable"><thead><tr><th>Invoice</th><th>Customer</th><th>Product</th><th>Qty</th><th>Total</th><th>Date</th><th>Recorded By</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php while($r=$rows->fetch_assoc()):?><tr><td><?=e($r['invoice_no'])?></td><td><?=e($r['customer_name']??'Walk-in')?></td><td><?=e($r['product_name'])?></td><td><?=number_format($r['quantity'],2)?></td><td>₱<?=number_format($r['total_price'],2)?></td><td><?=e($r['transaction_date'])?></td><td><?=e($r['recorded_by']??'Unknown')?></td><td><span class="badge"><?=e($r['payment_status'])?></span></td><td><a class="icon-link" href="?edit=<?=$r['id']?>">✎</a><?php if(can_delete_record($r['created_by'])):?><a class="icon-link" href="?delete=<?=$r['id']?>" onclick="return confirm('Delete transaction?')">⌫</a><?php endif;?></td></tr><?php endwhile;?></tbody></table></div></div>
<div class="modal-backdrop <?=$edit?'show':''?>" id="salesModal"><div class="modal"><div class="modal-head"><h3><?= $edit?'Edit Sale':'Record Sale'?></h3><button class="close" data-modal-close="#salesModal">×</button></div><form method="post"><input type="hidden" name="id" value="<?=e($edit['id']??'')?>"><div class="form-grid"><div><label>Invoice No.</label><input name="invoice_no" required value="<?=e($edit['invoice_no']??'INV-'.date('Ymd-His'))?>"></div><div><label>Customer</label><select name="customer_id"><option value="0">Walk-in Customer</option><?php while($c=$customers->fetch_assoc()):?><option value="<?=$c['id']?>" <?=((int)($edit['customer_id']??0)==$c['id'])?'selected':''?>><?=e($c['customer_name'])?></option><?php endwhile;?></select></div><div><label>Product</label><input id="saleProduct" name="product_name" required value="<?=e($edit['product_name']??'')?>" list="productList" autocomplete="off" placeholder="Type or choose a product"><datalist id="productList"><?php foreach($product_options as $p):?><option value="<?=e($p['product_name'])?>"><?=e($p['unit'])?> · ₱<?=number_format($p['price'],2)?></option><?php endforeach;?></datalist><small class="field-hint">Products are taken from the Price List and sorted alphabetically.</small></div><div><label>Quantity</label><input type="number" step="0.01" min="0" name="quantity" required value="<?=e($edit['quantity']??'')?>"></div><div><label>Unit Price</label><input id="saleUnitPrice" type="number" step="0.01" min="0" name="unit_price" required value="<?=e($edit['unit_price']??'')?>" readonly><small id="priceHint" class="field-hint">Select a Price List product to fill the unit price automatically.</small></div><div><label>Transaction Date</label><input type="date" name="transaction_date" required value="<?=e($edit['transaction_date']??date('Y-m-d'))?>"></div><div><label>Payment Status</label><select name="payment_status"><option <?= (($edit['payment_status']??'Paid')==='Paid')?'selected':''?>>Paid</option><option <?= (($edit['payment_status']??'')==='Pending')?'selected':''?>>Pending</option></select></div></div><div class="form-actions"><button type="button" class="btn secondary" data-modal-close="#salesModal">Cancel</button><button class="btn primary" name="save">Save</button></div></form></div></div>
<script>window.agribrewPrices=<?=json_encode($product_options,JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT)?>;</script>
<?php require_once __DIR__.'/../../includes/footer.php'; ?>
