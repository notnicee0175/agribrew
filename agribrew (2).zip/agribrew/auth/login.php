<?php
require_once __DIR__ . '/../config/config.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

$allowed_roles = ['Administrator', 'Cooperative Staff'];
$selected_role = $_POST['role'] ?? ($_GET['role'] ?? '');
if (!in_array($selected_role, $allowed_roles, true)) {
    redirect('index.php');
}

$error = '';

if (isset($_POST['login'])) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT id, full_name, username, password, role, email, position, location, profile_photo FROM users WHERE username = ? AND role = ? LIMIT 1");
    $stmt->bind_param("ss", $username, $selected_role);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        unset($user['password']);
        $_SESSION['user'] = $user;
        redirect('dashboard.php');
    }

    $error = 'The username or password is incorrect.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($selected_role) ?> Login - AgriBrew</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-card login-card-wide">
        <a class="login-back-link" href="<?= BASE_URL ?>index.php">← Choose account type</a>
        <div class="brand-mark">☕</div>
        <div class="kicker">AgriBrew</div>
        <h1><?= e(strtoupper($selected_role)) ?></h1>
        <p class="muted">Enter your account credentials to continue.</p>

        <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

        <form method="post" id="loginForm">
            <input type="hidden" name="role" value="<?= e($selected_role) ?>">
            <label>Username</label>
            <input type="text" name="username" required autofocus autocomplete="username">
            <label>Password</label>
            <input type="password" name="password" required autocomplete="current-password">
            <button class="btn primary full" type="submit" name="login">Sign In</button>
        </form>

        <div class="login-accounts">
            <?php if ($selected_role === 'Administrator'): ?>
                <small class="muted"><strong>Administrator account:</strong> admin / admin123</small>
            <?php else: ?>
                <small class="muted"><strong>Cooperative Staff account:</strong> staff / staff123</small>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
