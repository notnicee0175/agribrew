<?php
$page_title = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

$harvest = $conn->query("SELECT COALESCE(SUM(quantity),0) total FROM farming_records WHERE process_type='Harvesting'")->fetch_assoc()['total'];
$batches = $conn->query("SELECT COUNT(DISTINCT batch_id) total FROM farming_records")->fetch_assoc()['total'];
$stock = $conn->query("SELECT COALESCE(SUM(stock),0) total FROM inventory")->fetch_assoc()['total'];
$revenue = $conn->query("SELECT COALESCE(SUM(total_price),0) total FROM sales")->fetch_assoc()['total'];
$recent = $conn->query("SELECT process_type,batch_id,farmer_name,record_date,quantity,unit FROM farming_records ORDER BY id DESC LIMIT 8");
?>
<div class="grid cards-4">
    <div class="card stat-card"><div class="stat-label">Total Harvest</div><div class="stat-value"><?= number_format($harvest,2) ?> kg</div></div>
    <div class="card stat-card"><div class="stat-label">Coffee Batches</div><div class="stat-value"><?= number_format($batches) ?></div></div>
    <div class="card stat-card"><div class="stat-label">Available Inventory</div><div class="stat-value"><?= number_format($stock,2) ?></div></div>
    <div class="card stat-card"><div class="stat-label">Total Revenue</div><div class="stat-value">₱<?= number_format($revenue,2) ?></div></div>
</div>

<div class="card" style="margin-top:20px;">
    <div class="section-head">
        <div><span class="kicker">Activity</span><h3>Recent Coffee Farming Records</h3></div>
        <a class="btn primary" href="<?= BASE_URL ?>modules/farming/index.php">View Records</a>
    </div>
    <div class="toolbar"><input class="search" type="text" placeholder="Search records..." data-search="#recentTable"></div>
    <div class="table-wrap">
        <table id="recentTable">
            <thead><tr><th>Process</th><th>Batch</th><th>Farmer</th><th>Date</th><th>Quantity</th></tr></thead>
            <tbody>
            <?php if ($recent->num_rows): while ($r = $recent->fetch_assoc()): ?>
                <tr><td><span class="badge"><?= e($r['process_type']) ?></span></td><td><?= e($r['batch_id']) ?></td><td><?= e($r['farmer_name']) ?></td><td><?= e($r['record_date']) ?></td><td><?= number_format($r['quantity'],2) ?> <?= e($r['unit']) ?></td></tr>
            <?php endwhile; else: ?>
                <tr><td colspan="5" class="empty">No farming records yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
