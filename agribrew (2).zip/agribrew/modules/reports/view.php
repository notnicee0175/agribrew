<?php
require_once __DIR__.'/../../config/config.php';
require_login();
if(($_GET['type'] ?? 'production') !== 'production'){redirect('modules/reports/index.php');}

$report_id='REP-2026-001';
$generated=date('F d, Y');
$prepared=$_SESSION['user']['full_name'];
$harvest_rows=[];
$res=$conn->query("SELECT batch_id, farmer_name, variety, record_date, quantity, unit, quality_grade FROM farming_records WHERE process_type='Harvesting' ORDER BY record_date ASC, id ASC");
while($row=$res->fetch_assoc()){$harvest_rows[]=$row;}
$total_harvest=(float)$conn->query("SELECT COALESCE(SUM(quantity),0) n FROM farming_records WHERE process_type='Harvesting'")->fetch_assoc()['n'];
$batch_count=count($harvest_rows);
$premium=0;$specialty=0;
foreach($harvest_rows as $r){$grade=strtolower(trim((string)$r['quality_grade']));if($grade==='premium')$premium++;if($grade==='specialty')$specialty++;}
$highest=$batch_count ? max(array_map(fn($r)=>(float)$r['quantity'],$harvest_rows)) : 0;
$lowest=$batch_count ? min(array_map(fn($r)=>(float)$r['quantity'],$harvest_rows)) : 0;
$average=$batch_count ? $total_harvest/$batch_count : 0;
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?=e($report_id)?> - Production Report</title>
<link rel="stylesheet" href="<?=BASE_URL?>assets/css/style.css">
<style>
@page { size: A4 portrait; margin: 12mm; }
html, body { margin: 0; padding: 0; background: #f0ece7; }
.report-page { min-height: 100vh; padding: 30px; background: #f0ece7; }
.report-sheet { width: 100%; max-width: 960px; margin: 0 auto; box-sizing: border-box; background: #fff; padding: 30px 34px 36px; color: #222; }
.report-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 20px; }
.report-brand { display: flex; align-items: center; gap: 9px; }
.report-brand-icon { font-size: 25px; }
.report-brand strong { display: block; font-size: 21px; }
.report-brand span, .report-title span { display: block; font-size: 11px; color: #777; margin-top: 2px; }
.report-title { text-align: right; }
.report-title h1 { margin: 0; font-size: 18px; color: #111; }
.report-rule { border-bottom: 1px solid #777; margin: 13px 0 15px; }
.report-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.report-meta > div { background: #f3f3f3; padding: 11px 12px; min-height: 40px; }
.report-meta strong, .report-meta span { display: block; font-size: 11px; }
.report-meta span { margin-top: 4px; }
.report-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 18px 0; }
.report-stats > div { border: 1px solid #d9d9d9; border-radius: 4px; padding: 12px 9px; text-align: center; }
.report-stats span { display: block; font-size: 11px; }
.report-stats strong { display: block; font-size: 20px; margin-top: 7px; color: #111; }
.report-section { margin-top: 17px; }
.report-section h2 { border-left: 3px solid #555; padding-left: 8px; margin: 0 0 10px; font-size: 15px; }
.report-table { border-collapse: collapse; width: 100%; }
.report-table th, .report-table td { border: 1px solid #d5d5d5; padding: 8px 9px; font-size: 11px; color: #222; }
.report-table th { background: #595959; color: #fff; }
.report-table td { background: #fff; }
.report-table tbody tr:nth-child(even) td { background: #fafafa; }
.summary-table td:last-child, .summary-table th:last-child { text-align: right; }
.report-empty { text-align: center !important; color: #777 !important; }
.report-signatures { display: flex; justify-content: space-between; gap: 80px; margin-top: 35px; }
.report-signatures > div { width: 35%; text-align: center; font-size: 11px; }
.report-signatures span { display: block; border-top: 1px solid #999; margin-bottom: 8px; }
.report-signatures p { margin: 0; line-height: 1.5; }
.report-print-actions { display: flex; justify-content: center; gap: 10px; margin-top: 28px; }
@media print {
    html, body { background: #fff !important; }
    .report-page { padding: 0 !important; background: #fff !important; min-height: auto !important; }
    .report-sheet { max-width: none !important; width: 100% !important; margin: 0 !important; padding: 0 !important; box-shadow: none !important; }
    .report-print-actions { display: none !important; }
    .report-meta > div, .report-stats > div, .report-table th { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
}
</style>
</head><body class="report-page">
<div class="report-sheet">
    <div class="report-header"><div class="report-brand"><div class="report-brand-icon">☕</div><div><strong>AgriBrew</strong><span>Tiblac Cooperative</span></div></div><div class="report-title"><h1>Production Report</h1><span>Generated Report</span></div></div>
    <div class="report-rule"></div>
    <div class="report-meta"><div><strong>Report ID:</strong><span><?=e($report_id)?></span></div><div><strong>Date Generated:</strong><span><?=e($generated)?></span></div><div><strong>Report Period:</strong><span>All recorded harvests</span></div><div><strong>Prepared By:</strong><span><?=e($prepared)?></span></div></div>
    <div class="report-stats"><div><span>Total Harvest</span><strong><?=number_format($total_harvest,2)?> kg</strong></div><div><span>Total Batches</span><strong><?=number_format($batch_count)?></strong></div><div><span>Premium Grade</span><strong><?=number_format($premium)?></strong></div><div><span>Specialty Grade</span><strong><?=number_format($specialty)?></strong></div></div>
    <section class="report-section"><h2>Harvest Records</h2><div class="report-table-wrap"><table class="report-table"><thead><tr><th>Batch ID</th><th>Farmer</th><th>Date</th><th>Variety</th><th>Weight</th><th>Grade</th></tr></thead><tbody>
    <?php if($harvest_rows): foreach($harvest_rows as $r): ?><tr><td><?=e($r['batch_id'])?></td><td><?=e($r['farmer_name'])?></td><td><?=e(date('M d',strtotime($r['record_date'])))?></td><td><?=e($r['variety'] ?: '—')?></td><td><?=number_format((float)$r['quantity'],2)?> <?=e($r['unit'])?></td><td><?=e($r['quality_grade'] ?: '—')?></td></tr><?php endforeach; else: ?><tr><td colspan="6" class="report-empty">No harvest records have been recorded yet.</td></tr><?php endif; ?>
    </tbody></table></div></section>
    <section class="report-section"><h2>Production Summary</h2><table class="report-table summary-table"><thead><tr><th>Description</th><th>Value</th></tr></thead><tbody><tr><td>Total Harvest</td><td><?=number_format($total_harvest,2)?> kg</td></tr><tr><td>Highest Harvest</td><td><?=number_format($highest,2)?> kg</td></tr><tr><td>Lowest Harvest</td><td><?=number_format($lowest,2)?> kg</td></tr><tr><td>Average Harvest</td><td><?=number_format($average,2)?> kg</td></tr></tbody></table></section>
    <div class="report-signatures"><div><span></span><p>Prepared by<br><strong><?=e($prepared)?></strong></p></div><div><span></span><p>Approved by<br><strong>Cooperative Manager</strong></p></div></div>
    <div class="report-print-actions"><button class="btn primary" onclick="window.print()">▣ Print Report</button><a class="btn secondary" href="index.php">Back to Reports</a></div>
</div>
<?php if(isset($_GET['print'])): ?><script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 350); });</script><?php endif; ?>
</body></html>
