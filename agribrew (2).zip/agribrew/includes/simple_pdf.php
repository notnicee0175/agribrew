<?php
/**
 * Small dependency-free PDF helper for AgriBrew reports.
 * It creates standard A4 PDFs using built-in PDF fonts, so teammates do not
 * need Composer or an external PDF library just to download a report.
 */
class AgriBrewPDF
{
    private float $width = 595.28;
    private float $height = 841.89;
    private array $pages = [];
    private string $current = '';

    public function addPage(): void
    {
        if ($this->current !== '') {
            $this->pages[] = $this->current;
        }
        $this->current = "q\n1 0 0 1 0 0 cm\n";
    }

    public function text(float $x, float $y, string $text, float $size = 10, string $font = 'F1'): void
    {
        $text = $this->encodeText($text);
        $this->current .= "BT /{$font} {$size} Tf 1 0 0 1 {$this->fmt($x)} {$this->fmt($y)} Tm ({$text}) Tj ET\n";
    }

    public function line(float $x1, float $y1, float $x2, float $y2): void
    {
        $this->current .= "{$this->fmt($x1)} {$this->fmt($y1)} m {$this->fmt($x2)} {$this->fmt($y2)} l S\n";
    }

    public function rect(float $x, float $y, float $w, float $h, bool $fill = false): void
    {
        $this->current .= "{$this->fmt($x)} {$this->fmt($y)} {$this->fmt($w)} {$this->fmt($h)} re " . ($fill ? 'f' : 'S') . "\n";
    }

    public function fillGray(float $gray): void
    {
        $this->current .= $this->fmt($gray) . " g\n";
    }

    public function strokeGray(float $gray): void
    {
        $this->current .= $this->fmt($gray) . " G\n";
    }

    public function setLineWidth(float $width): void
    {
        $this->current .= $this->fmt($width) . " w\n";
    }

    public function output(string $filename): void
    {
        if ($this->current !== '') {
            $this->pages[] = $this->current . "Q\n";
        }

        $objects = [];
        $objects[] = '<< /Type /Catalog /Pages 2 0 R >>';
        $pageObjectNumbers = [];
        $next = 5 + count($this->pages) * 2;
        $fontRegular = 3;
        $fontBold = 4;

        foreach ($this->pages as $index => $content) {
            $pageNum = 5 + ($index * 2);
            $contentNum = $pageNum + 1;
            $pageObjectNumbers[] = $pageNum;
            $objects[$pageNum - 1] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {$this->fmt($this->width)} {$this->fmt($this->height)}] /Resources << /Font << /F1 {$fontRegular} 0 R /F2 {$fontBold} 0 R >> >> /Contents {$contentNum} 0 R >>";
            $objects[$contentNum - 1] = "<< /Length " . strlen($content) . " >>\nstream\n" . $content . "endstream";
        }

        $kids = implode(' ', array_map(fn($n) => $n . ' 0 R', $pageObjectNumbers));
        $objects[1] = "<< /Type /Pages /Kids [{$kids}] /Count " . count($pageObjectNumbers) . " >>";
        $objects[$fontRegular - 1] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objects[$fontBold - 1] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';

        ksort($objects);
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [0];
        $maxObject = max(array_keys($objects)) + 1;
        for ($i = 1; $i <= $maxObject; $i++) {
            $offsets[$i] = strlen($pdf);
            $pdf .= "{$i} 0 obj\n" . ($objects[$i - 1] ?? '<< >>') . "\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 {$maxObject}\n0000000000 65535 f \n";
        for ($i = 1; $i < $maxObject; $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i] ?? 0);
        }
        $pdf .= "trailer\n<< /Size {$maxObject} /Root 1 0 R >>\nstartxref\n{$xref}\n%%EOF";

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($pdf));
        echo $pdf;
        exit;
    }

    private function fmt(float $number): string
    {
        return number_format($number, 2, '.', '');
    }

    private function encodeText(string $text): string
    {
        $text = trim(preg_replace('/\s+/u', ' ', $text));
        $converted = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);
        if ($converted !== false) {
            $text = $converted;
        }
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
    }
}
