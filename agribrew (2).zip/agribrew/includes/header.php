<?php
require_once __DIR__ . '/../config/config.php';
require_login();
$page_title = $page_title ?? 'Dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($page_title) ?> - AgriBrew</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <a class="brand brand-link" href="<?= BASE_URL ?>dashboard.php" aria-label="Go to Dashboard">
            <div class="brand-icon">☕</div>
            <div>
                <strong>AgriBrew</strong>
                <span>Tiblac Cooperative</span>
            </div>
        </a>

        <nav>
            <a href="<?= BASE_URL ?>dashboard.php" class="<?= $page_title === 'Dashboard' ? 'active' : '' ?>">⌂ <span>Dashboard</span></a>
            <div class="nav-label">Coffee Farming Records</div>
            <a href="<?= BASE_URL ?>modules/farming/index.php" class="<?= $page_title === 'Coffee Farming Records' ? 'active' : '' ?>">▣ <span>Farming Records</span></a>
            <a href="<?= BASE_URL ?>modules/inventory/index.php" class="<?= $page_title === 'Inventory' ? 'active' : '' ?>">▤ <span>Inventory</span></a>
            <div class="nav-label">Sales</div>
            <a href="<?= BASE_URL ?>modules/sales/index.php" class="<?= $page_title === 'Sales Transactions' ? 'active' : '' ?>">₱ <span>Transactions</span></a>
            <a href="<?= BASE_URL ?>modules/sales/customers.php" class="<?= $page_title === 'Customers' ? 'active' : '' ?>">♙ <span>Customers</span></a>
            <a href="<?= BASE_URL ?>modules/sales/prices.php" class="<?= $page_title === 'Price List' ? 'active' : '' ?>">₱ <span>Price List</span></a>
            <div class="nav-label">Finance</div>
            <a href="<?= BASE_URL ?>modules/finance/index.php" class="<?= $page_title === 'Expenses' ? 'active' : '' ?>">▧ <span>Expenses</span></a>
            <a href="<?= BASE_URL ?>modules/reports/index.php" class="<?= $page_title === 'Reports' ? 'active' : '' ?>">▥ <span>Reports</span></a>
            <?php if (is_admin()): ?>
                <div class="nav-label">Administration</div>
                <a href="<?= BASE_URL ?>users.php" class="<?= $page_title === 'User Management' ? 'active' : '' ?>">⚙ <span>Users</span></a>
            <?php endif; ?>
        </nav>

        <div class="sidebar-bottom">
            <a href="<?= BASE_URL ?>profile.php">◉ <span>Profile</span></a>
            <a href="<?= BASE_URL ?>auth/logout.php">↪ <span>Sign Out</span></a>
        </div>
    </aside>

    <main class="main">
        <header class="topbar">
            <div>
                <h2><?= e($page_title) ?></h2>
                <span class="muted">Tiblac Farmers Agriculture Cooperative</span>
            </div>
            <a class="user-chip user-chip-link" href="<?= BASE_URL ?>profile.php" aria-label="Open Profile">
                <?php $header_photo = !empty($_SESSION['user']['profile_photo']) ? BASE_URL.'uploads/profiles/'.rawurlencode($_SESSION['user']['profile_photo']) : ''; ?>
                <?php if ($header_photo): ?><img class="avatar avatar-image" src="<?= e($header_photo) ?>" alt="Profile photo"><?php else: ?><div class="avatar"><?= strtoupper(substr($_SESSION['user']['full_name'], 0, 1)) ?></div><?php endif; ?>
                <div><strong><?= e($_SESSION['user']['full_name']) ?></strong><small><?= e($_SESSION['user']['role']) ?></small></div>
            </a>
        </header>
        <section class="content">
            <?php show_flash(); ?>
