CREATE DATABASE IF NOT EXISTS agribrew_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE agribrew_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    username VARCHAR(60) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Administrator','Cooperative Staff') NOT NULL DEFAULT 'Cooperative Staff',
    email VARCHAR(120) DEFAULT NULL,
    position VARCHAR(100) DEFAULT NULL,
    location VARCHAR(150) DEFAULT NULL,
    profile_photo VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS farming_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    process_type ENUM('Harvesting','Drying','Dehulling','Sorting','Roasting','Grinding','Packaging','Marketing') NOT NULL,
    batch_id VARCHAR(50) NOT NULL,
    farmer_name VARCHAR(120) NOT NULL,
    variety VARCHAR(80) DEFAULT NULL,
    farm_name VARCHAR(120) DEFAULT NULL,
    record_date DATE NOT NULL,
    quantity DECIMAL(12,2) NOT NULL DEFAULT 0,
    unit VARCHAR(30) NOT NULL DEFAULT 'kg',
    quality_grade VARCHAR(50) DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(120) NOT NULL,
    category VARCHAR(80) DEFAULT NULL,
    stock DECIMAL(12,2) NOT NULL DEFAULT 0,
    unit VARCHAR(30) NOT NULL DEFAULT 'kg',
    reorder_level DECIMAL(12,2) NOT NULL DEFAULT 0,
    created_by INT DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(120) NOT NULL,
    contact VARCHAR(80) DEFAULT NULL,
    address VARCHAR(200) DEFAULT NULL,
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS price_list (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(120) NOT NULL,
    unit VARCHAR(30) NOT NULL DEFAULT 'kg',
    price DECIMAL(12,2) NOT NULL DEFAULT 0,
    created_by INT DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_no VARCHAR(50) NOT NULL UNIQUE,
    customer_id INT DEFAULT NULL,
    product_name VARCHAR(120) NOT NULL,
    quantity DECIMAL(12,2) NOT NULL DEFAULT 0,
    unit_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    transaction_date DATE NOT NULL,
    payment_status ENUM('Paid','Pending') NOT NULL DEFAULT 'Paid',
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(80) NOT NULL,
    description VARCHAR(200) DEFAULT NULL,
    amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    expense_date DATE NOT NULL,
    person_responsible VARCHAR(120) DEFAULT NULL,
    created_by INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

INSERT INTO users (full_name, username, password, role, email, position)
SELECT 'System Administrator', 'admin', '$2y$12$CMbEvMXZMUFb1pTjHvEen.3e98z7Wgom9tK96NQDaD4y6bnv5p4Uu', 'Administrator', 'admin@agribrew.local', 'Administrator'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='admin');


INSERT INTO users (full_name, username, password, role, email, position)
SELECT 'Cooperative Staff', 'staff', '$2y$12$3XyIIrOgHeFmJGwzfGdy4OWB2j4QkdQzUb/wqskp7HdrfKzVLPY5u', 'Cooperative Staff', 'staff@agribrew.local', 'Cooperative Staff'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='staff');

INSERT INTO inventory (product_name, category, stock, unit, reorder_level)
SELECT 'Coffee Beans', 'Coffee Product', 0, 'kg', 10
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE product_name='Coffee Beans');
