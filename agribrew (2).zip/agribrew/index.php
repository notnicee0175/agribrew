<?php
require_once __DIR__ . '/config/config.php';
if (is_logged_in()) {
    redirect('dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AgriBrew - Authentication</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body class="authentication-page">
    <main class="authentication-frame">
        <div class="authentication-content">
            <img class="authentication-logo" src="<?= BASE_URL ?>assets/images/tibfac-logo.png" alt="Tiblac Farmers Agriculture Cooperative logo">
            <div class="authentication-brand">AgriBrew</div>
            <div class="authentication-coop-name">TIBLAC FARMERS AGRICULTURE COOPERATIVE</div>

            <div class="authentication-role-buttons">
                <a class="authentication-role-button" href="<?= BASE_URL ?>auth/login.php?role=Administrator">ADMINISTRATOR</a>
                <a class="authentication-role-button" href="<?= BASE_URL ?>auth/login.php?role=Cooperative%20Staff">COOPERATIVE STAFF</a>
            </div>
        </div>
    </main>
</body>
</html>
