<?php
$page_title = 'Coffee Farming Records';
require_once __DIR__ . '/../../includes/header.php';

$edit = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM farming_records WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $edit = $stmt->get_result()->fetch_assoc();
    if (!$edit || !can_edit_record($edit['created_by'])) {
        flash('error', 'You can only edit records created by your account.');
        redirect('modules/farming/index.php');
    }
}

$next_batch = 'B001';
$next_result = $conn->query("SELECT MAX(CAST(SUBSTRING(batch_id, 2) AS UNSIGNED)) AS max_batch FROM farming_records WHERE batch_id REGEXP '^B[0-9]+$'");
if ($next_result) {
    $max_batch = (int)($next_result->fetch_assoc()['max_batch'] ?? 0);
    $next_batch = 'B' . str_pad((string)($max_batch + 1), 3, '0', STR_PAD_LEFT);
}

if (isset($_POST['save'])) {
    $process = trim($_POST['process_type']);
    $batch = trim($_POST['batch_id']);
    $farmer = trim($_POST['farmer_name']);
    $variety = trim($_POST['variety']);
    $farm = trim($_POST['farm_name']);
    $date = $_POST['record_date'];
    $quantity = (float)$_POST['quantity'];
    $unit = trim($_POST['unit']);
    $grade = trim($_POST['quality_grade']);
    $notes = trim($_POST['notes']);
    $created_by = (int)$_SESSION['user']['id'];

    if (!empty($_POST['id'])) {
        $id = (int)$_POST['id'];
        $check = $conn->prepare("SELECT created_by FROM farming_records WHERE id=?");
        $check->bind_param("i", $id);
        $check->execute();
        $owner = $check->get_result()->fetch_assoc();
        if (!$owner || !can_edit_record($owner['created_by'])) {
            flash('error', 'You can only edit records created by your account.');
            redirect('modules/farming/index.php');
        }
        $stmt = $conn->prepare("UPDATE farming_records SET process_type=?, batch_id=?, farmer_name=?, variety=?, farm_name=?, record_date=?, quantity=?, unit=?, quality_grade=?, notes=? WHERE id=?");
        $stmt->bind_param("ssssssdsssi", $process, $batch, $farmer, $variety, $farm, $date, $quantity, $unit, $grade, $notes, $id);
        $stmt->execute();
        flash('success', 'Farming record updated.');
    } else {
        if ($batch === '') {
            $batch = $next_batch;
        }
        $stmt = $conn->prepare("INSERT INTO farming_records (process_type,batch_id,farmer_name,variety,farm_name,record_date,quantity,unit,quality_grade,notes,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("ssssssdsssi", $process, $batch, $farmer, $variety, $farm, $date, $quantity, $unit, $grade, $notes, $created_by);
        $stmt->execute();
        flash('success', 'Farming record added.');
    }
    redirect('modules/farming/index.php');
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("SELECT created_by FROM farming_records WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $owner = $stmt->get_result()->fetch_assoc();
    if ($owner && can_delete_record($owner['created_by'])) {
        $stmt = $conn->prepare("DELETE FROM farming_records WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        flash('success', 'Farming record deleted.');
    } else {
        flash('error', 'You can only delete records created by your account.');
    }
    redirect('modules/farming/index.php');
}

$rows = $conn->query("SELECT f.*, u.full_name AS recorded_by FROM farming_records f LEFT JOIN users u ON u.id=f.created_by ORDER BY f.record_date DESC, f.id DESC");
?>
<div class="card">
    <div class="section-head">
        <div><span class="kicker">Records</span><h3>Harvesting to Marketing</h3><div class="muted">Every record automatically stores the account that created it.</div></div>
        <button class="btn primary" data-modal-open="#recordModal">+ Add Record</button>
    </div>
    <div class="toolbar"><input class="search" type="text" placeholder="Search records..." data-search="#recordsTable"></div>
    <div class="table-wrap">
        <table id="recordsTable">
            <thead><tr><th>Process</th><th>Batch</th><th>Farmer</th><th>Variety</th><th>Farm</th><th>Date</th><th>Quantity</th><th>Recorded By</th><th>Grade</th><th>Actions</th></tr></thead>
            <tbody>
            <?php if ($rows->num_rows): while ($r=$rows->fetch_assoc()): ?>
                <tr>
                    <td><?= e($r['process_type']) ?></td><td><?= e($r['batch_id']) ?></td><td><?= e($r['farmer_name']) ?></td><td><?= e($r['variety']) ?></td><td><?= e($r['farm_name']) ?></td><td><?= e($r['record_date']) ?></td><td><?= number_format($r['quantity'],2) ?> <?= e($r['unit']) ?></td><td><?= e($r['recorded_by'] ?? 'Unknown') ?></td><td><?= e($r['quality_grade']) ?></td>
                    <td class="actions"><a class="icon-link" title="Edit" href="?edit=<?= $r['id'] ?>">✎</a><?php if (can_delete_record($r['created_by'])): ?><a class="icon-link" title="Delete" href="?delete=<?= $r['id'] ?>" onclick="return confirm('Delete this record?')">⌫</a><?php endif; ?></td>
                </tr>
            <?php endwhile; else: ?><tr><td colspan="10" class="empty">No records yet.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal-backdrop <?= $edit ? 'show' : '' ?>" id="recordModal">
    <div class="modal">
        <div class="modal-head"><h3><?= $edit ? 'Edit Farming Record' : 'Add Farming Record' ?></h3><button class="close" data-modal-close="#recordModal">×</button></div>
        <form method="post">
            <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
            <div class="form-grid">
                <div><label>Process</label><select name="process_type" required><?php foreach(['Harvesting','Drying','Dehulling','Sorting','Roasting','Grinding','Packaging','Marketing'] as $p): ?><option <?= (($edit['process_type'] ?? '')===$p)?'selected':'' ?>><?= $p ?></option><?php endforeach; ?></select></div>
                <div><label>Batch ID</label><div class="input-with-action"><input id="batchId" name="batch_id" required value="<?= e($edit['batch_id'] ?? $next_batch) ?>" <?= !$edit ? 'readonly' : 'readonly' ?>><button type="button" class="field-edit-btn" data-enable-input="#batchId">Edit</button></div><small class="field-hint">New records automatically continue from the previous batch number.</small></div>
                <div><label>Farmer Name</label><input name="farmer_name" required value="<?= e($edit['farmer_name'] ?? '') ?>"></div>
                <div><label>Variety</label><input name="variety" value="<?= e($edit['variety'] ?? '') ?>"></div>
                <div><label>Farm Name</label><input name="farm_name" value="<?= e($edit['farm_name'] ?? '') ?>"></div>
                <div><label>Record Date</label><div class="input-with-action"><input id="recordDate" type="date" name="record_date" required value="<?= e($edit['record_date'] ?? date('Y-m-d')) ?>" readonly><button type="button" class="field-edit-btn" data-enable-input="#recordDate">Edit</button></div><small class="field-hint">Defaults to today. Use Edit for a late record.</small></div>
                <div><label>Quantity</label><input type="number" step="0.01" min="0" name="quantity" required value="<?= e($edit['quantity'] ?? '') ?>"></div>
                <div><label>Unit</label><input name="unit" value="<?= e($edit['unit'] ?? 'kg') ?>"></div>
                <div><label>Quality Grade</label><input name="quality_grade" value="<?= e($edit['quality_grade'] ?? '') ?>"></div>
                <div class="full-row"><label>Notes</label><textarea name="notes" rows="3"><?= e($edit['notes'] ?? '') ?></textarea></div>
                <div class="full-row"><label>Recorded By</label><input value="<?= e($_SESSION['user']['full_name']) ?>" readonly><small class="field-hint">This is taken automatically from the signed-in account and cannot be typed over.</small></div>
            </div>
            <div class="form-actions"><button type="button" class="btn secondary" data-modal-close="#recordModal">Cancel</button><button class="btn primary" name="save">Save Record</button></div>
        </form>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
