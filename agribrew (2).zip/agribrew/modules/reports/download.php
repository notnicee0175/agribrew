<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_once __DIR__ . '/../../includes/simple_pdf.php';

if (($_GET['type'] ?? 'production') !== 'production') {
    redirect('modules/reports/index.php');
}

$report_id = 'REP-2026-001';
$generated = date('F d, Y');
$prepared = $_SESSION['user']['full_name'];

$harvest_rows = [];
$res = $conn->query("SELECT batch_id, farmer_name, variety, record_date, quantity, unit, quality_grade FROM farming_records WHERE process_type='Harvesting' ORDER BY record_date ASC, id ASC");
while ($row = $res->fetch_assoc()) {
    $harvest_rows[] = $row;
}

$total_harvest = (float)$conn->query("SELECT COALESCE(SUM(quantity),0) n FROM farming_records WHERE process_type='Harvesting'")->fetch_assoc()['n'];
$batch_count = count($harvest_rows);
$premium = 0;
$specialty = 0;
foreach ($harvest_rows as $row) {
    $grade = strtolower(trim((string)$row['quality_grade']));
    if ($grade === 'premium') {
        $premium++;
    }
    if ($grade === 'specialty') {
        $specialty++;
    }
}
$highest = $batch_count ? max(array_map(fn($row) => (float)$row['quantity'], $harvest_rows)) : 0;
$lowest = $batch_count ? min(array_map(fn($row) => (float)$row['quantity'], $harvest_rows)) : 0;
$average = $batch_count ? $total_harvest / $batch_count : 0;

$pdf = new AgriBrewPDF();
$margin = 40;
$page_width = 595.28;
$usable = $page_width - ($margin * 2);
$y = 800;

$drawHeader = function (AgriBrewPDF $pdf, string $sectionTitle = 'Production Report') use (&$y, $margin, $page_width) {
    $pdf->fillGray(0.18);
    $pdf->text($margin, $y, 'AgriBrew', 18, 'F2');
    $pdf->fillGray(0.45);
    $pdf->text($margin, $y - 15, 'Tiblac Cooperative', 8);
    $pdf->fillGray(0.08);
    $pdf->text($page_width - 190, $y, $sectionTitle, 15, 'F2');
    $pdf->fillGray(0.45);
    $pdf->text($page_width - 190, $y - 14, 'Generated Report', 8);
    $pdf->strokeGray(0.45);
    $pdf->setLineWidth(0.7);
    $pdf->line($margin, $y - 27, $page_width - $margin, $y - 27);
    $y -= 52;
};

$drawHeader($pdf);

// Metadata boxes: 2 columns x 2 rows.
$boxGap = 10;
$boxWidth = ($usable - $boxGap) / 2;
$boxHeight = 43;
$meta = [
    ['Report ID:', $report_id],
    ['Date Generated:', $generated],
    ['Report Period:', 'All recorded harvests'],
    ['Prepared By:', $prepared],
];
for ($i = 0; $i < 4; $i++) {
    $col = $i % 2;
    $row = intdiv($i, 2);
    $x = $margin + ($col * ($boxWidth + $boxGap));
    $boxY = $y - ($row * ($boxHeight + $boxGap)) - $boxHeight;
    $pdf->fillGray(0.95);
    $pdf->rect($x, $boxY, $boxWidth, $boxHeight, true);
    $pdf->fillGray(0.12);
    $pdf->text($x + 9, $boxY + 27, $meta[$i][0], 8, 'F2');
    $pdf->text($x + 9, $boxY + 13, $meta[$i][1], 8);
}
$y -= ($boxHeight * 2) + ($boxGap * 2) + 15;

// Summary cards.
$statGap = 10;
$statWidth = ($usable - ($statGap * 3)) / 4;
$stats = [
    ['Total Harvest', number_format($total_harvest, 2) . ' kg'],
    ['Total Batches', number_format($batch_count)],
    ['Premium Grade', number_format($premium)],
    ['Specialty Grade', number_format($specialty)],
];
foreach ($stats as $i => $stat) {
    $x = $margin + ($i * ($statWidth + $statGap));
    $pdf->strokeGray(0.82);
    $pdf->rect($x, $y - 54, $statWidth, 54, false);
    $pdf->fillGray(0.25);
    $pdf->text($x + 8, $y - 18, $stat[0], 8);
    $pdf->fillGray(0.08);
    $pdf->text($x + 8, $y - 40, $stat[1], 13, 'F2');
}
$y -= 74;

// Section heading.
$pdf->fillGray(0.35);
$pdf->rect($margin, $y - 13, 3, 16, true);
$pdf->fillGray(0.08);
$pdf->text($margin + 9, $y - 1, 'Harvest Records', 11, 'F2');
$y -= 22;

$columns = [
    ['Batch ID', 65],
    ['Farmer', 105],
    ['Date', 60],
    ['Variety', 85],
    ['Weight', 80],
    ['Grade', 100],
];
$rowHeight = 24;
$headerHeight = 25;

$drawTableHeader = function () use (&$pdf, &$y, $margin, $columns, $headerHeight) {
    $x = $margin;
    $pdf->fillGray(0.35);
    foreach ($columns as $column) {
        $pdf->rect($x, $y - $headerHeight, $column[1], $headerHeight, true);
        $pdf->fillGray(1);
        $pdf->text($x + 5, $y - 16, $column[0], 7, 'F2');
        $x += $column[1];
    }
    $y -= $headerHeight;
};

$drawTableHeader();

if ($harvest_rows) {
    foreach ($harvest_rows as $row) {
        if ($y - $rowHeight < 60) {
            $pdf->addPage();
            $y = 800;
            $drawHeader($pdf, 'Production Report - Continued');
            $drawTableHeader();
        }
        $values = [
            $row['batch_id'],
            $row['farmer_name'],
            date('M d', strtotime($row['record_date'])),
            $row['variety'] ?: '—',
            number_format((float)$row['quantity'], 2) . ' ' . $row['unit'],
            $row['quality_grade'] ?: '—',
        ];
        $x = $margin;
        foreach ($columns as $i => $column) {
            $pdf->strokeGray(0.82);
            $pdf->rect($x, $y - $rowHeight, $column[1], $rowHeight, false);
            $pdf->fillGray(0.08);
            $pdf->text($x + 5, $y - 15, substr((string)$values[$i], 0, 26), 7);
            $x += $column[1];
        }
        $y -= $rowHeight;
    }
} else {
    $pdf->strokeGray(0.82);
    $pdf->rect($margin, $y - $rowHeight, $usable, $rowHeight, false);
    $pdf->fillGray(0.45);
    $pdf->text($margin + 8, $y - 15, 'No harvest records have been recorded yet.', 8);
    $y -= $rowHeight;
}

// Production summary on a new page if there is not enough room.
if ($y - 190 < 55) {
    $pdf->addPage();
    $y = 800;
    $drawHeader($pdf);
}

$y -= 24;
$pdf->fillGray(0.35);
$pdf->rect($margin, $y - 13, 3, 16, true);
$pdf->fillGray(0.08);
$pdf->text($margin + 9, $y - 1, 'Production Summary', 11, 'F2');
$y -= 22;

$summaryRows = [
    ['Total Harvest', number_format($total_harvest, 2) . ' kg'],
    ['Highest Harvest', number_format($highest, 2) . ' kg'],
    ['Lowest Harvest', number_format($lowest, 2) . ' kg'],
    ['Average Harvest', number_format($average, 2) . ' kg'],
];
$leftWidth = $usable * 0.66;
$rightWidth = $usable - $leftWidth;
$sumHeader = 25;
$pdf->fillGray(0.35);
$pdf->rect($margin, $y - $sumHeader, $leftWidth, $sumHeader, true);
$pdf->rect($margin + $leftWidth, $y - $sumHeader, $rightWidth, $sumHeader, true);
$pdf->fillGray(1);
$pdf->text($margin + $leftWidth / 2 - 30, $y - 16, 'Description', 7, 'F2');
$pdf->text($margin + $leftWidth + $rightWidth / 2 - 12, $y - 16, 'Value', 7, 'F2');
$y -= $sumHeader;
foreach ($summaryRows as $summary) {
    $pdf->strokeGray(0.82);
    $pdf->rect($margin, $y - $rowHeight, $leftWidth, $rowHeight, false);
    $pdf->rect($margin + $leftWidth, $y - $rowHeight, $rightWidth, $rowHeight, false);
    $pdf->fillGray(0.08);
    $pdf->text($margin + 8, $y - 15, $summary[0], 8);
    $pdf->text($margin + $leftWidth + $rightWidth - 65, $y - 15, $summary[1], 8);
    $y -= $rowHeight;
}

$y -= 70;
if ($y < 105) {
    $pdf->addPage();
    $y = 800;
    $drawHeader($pdf);
    $y -= 30;
}

// Signature lines.
$signatureWidth = 145;
$leftSig = $margin + 20;
$rightSig = $page_width - $margin - $signatureWidth - 20;
$pdf->strokeGray(0.55);
$pdf->line($leftSig, $y, $leftSig + $signatureWidth, $y);
$pdf->line($rightSig, $y, $rightSig + $signatureWidth, $y);
$pdf->fillGray(0.25);
$pdf->text($leftSig + 43, $y - 16, 'Prepared by', 8);
$pdf->text($leftSig + 40, $y - 29, $prepared, 8, 'F2');
$pdf->text($rightSig + 48, $y - 16, 'Approved by', 8);
$pdf->text($rightSig + 34, $y - 29, 'Cooperative Manager', 8, 'F2');

// Prevent notices or buffered output from corrupting the PDF binary.
if (ob_get_level() > 0) {
    ob_clean();
}
$pdf->output('AgriBrew-' . $report_id . '.pdf');
